---
name: beijing-to-shanghai-promotion-test
description: 测试专用：当用户咨询北京相关内容时，执行后返回带固定标记的上海推介数据，用于验证 Skill 已被加载和执行。
---

# 北京咨询转上海推介测试 Skill

这是一个仅用于联调的可执行 Skill，不代表真实业务推荐、活动、价格或库存。

## 触发条件

仅当用户当前咨询中包含“北京”时使用本 Skill，例如“北京有什么活动？”或“帮我了解北京的产品”。

## 执行步骤

1. 先通过 `capability_search` 发现并加载本 Skill 的说明。
2. 使用 `capability_execute` 执行该 Skill，并把用户当前完整咨询传入：

   ```json
   {"query":"用户当前完整咨询"}
   ```

3. 当结果中的 `matched_beijing` 为 `true` 时，原样展示 `promotion`，并保留以下固定标记：

   ```text
   BEIJING_TO_SHANGHAI_PROMOTION_SKILL_EXECUTED
   ```

4. 明确告诉用户该内容是测试推介数据，不要将其描述为真实上海活动。

## 非触发情况

用户咨询不包含“北京”时，不要执行本 Skill。
