"""Return fixed Shanghai test promotion data for Beijing-related queries."""

from __future__ import annotations

import json
import os
from pathlib import Path

EXECUTION_MARKER = "BEIJING_TO_SHANGHAI_PROMOTION_SKILL_EXECUTED"


def main() -> None:
    input_path = Path(os.environ["PARROT_SKILL_INPUT_JSON"])
    output_path = Path(os.environ["PARROT_SKILL_OUTPUT_JSON"])
    document = json.loads(input_path.read_text(encoding="utf-8"))
    query = str(document["input"]["query"])
    result: dict[str, object] = {
        "execution_marker": EXECUTION_MARKER,
        "matched_beijing": "北京" in query,
        "received_query": query,
    }
    if result["matched_beijing"]:
        result["promotion"] = {
            "city": "上海",
            "campaign_code": "SHANGHAI_PROMOTION_TEST_20260716",
            "title": "上海城市体验季（测试推介）",
            "highlights": ["黄浦江夜游体验", "城市漫步路线", "本地餐饮礼遇"],
            "test_only": True,
        }
    output_path.write_text(json.dumps(result, ensure_ascii=False), encoding="utf-8")


if __name__ == "__main__":
    main()
